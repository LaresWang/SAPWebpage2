sap.ui.define([], function () {
  return {
    "list2": {
      "sap.card": {
        "type": "List",
        "header": {
          "title": "Quick Links",
          "subTitle": " ",
        },
        "content": {
          "data": {
            "json": [
              {
                "name": "Template-Based Segmentation",
                "icon": "sap-icon://horizontal-bullet-chart",
              },
              {
                "name": "Marketing Plans",
                "icon": "sap-icon://line-charts",
              },
              {
                "name": "Target Groups",
                "icon": "sap-icon://horizontal-bar-chart",
              },
              {
                "name": "Program Structure",
                "icon": "sap-icon://org-chart",
              },
              {
                "name": "AdWords Campaigns",
                "icon": "sap-icon://bar-chart",
              }
            ]
          },
          "item": {
            "icon": {
              "src": "{icon}"
            },
            "title": {
              "value": "{name}"
            },
            "description": {
              "value": "{description}"
            },
            "info": {
              "value": "{info}",
              "state": "{infoState}"
            }
          }
        }
      }
    },
    "list1": {
      // "sap.app": {
      //   "type": "card"
      // },
      "sap.card": {
        "type": "Timeline",
        "header": {
          "title": "Upcoming Events",
          "subTitle": "For Today",
        },
        "content": {
          "data": {
            "json": [
              {
                "Title": "Weekly Sync: Sales and Marketing",
                "Icon": "sap-icon://appointment-2",
                "Time": "10:00 - 10:30",
                "Description": "MRR WDF18 C3.2 (GLASSBOX)",
              },
              {
                "Title": "Delivery Preparation: Pick & Pack",
                "Icon": "sap-icon://product",
                "Time": "14:30 - 15:30",
                "Description": "Warehouse 01, Bin Location 17",
              },
              {
                "Title": "Final Quotes Deadline",
                "Icon": "sap-icon://sales-quote",
                "Time": "15:00 - 16:30",
                "Description": "Send to Customer: XYZ co., Ltd",
              }
            ]
          },
          "item": {
            "dateTime": {
              "value": "{Time}"
            },
            "description": {
              "value": "{Description}"
            },
            "title": {
              "value": "{Title}"
            },
            "icon": {
              "src": "{Icon}"
            }
          }
        }
      }
    }
  }
})
