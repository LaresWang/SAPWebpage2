sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/ui/integration/library",
  "../model/card"
], function (Controller, JSONModel, MessageToast, integrationLibrary, card) {
  "use strict";

  return Controller.extend("ui.glance.controller.MainView", {
    onInit: function () {
      var cardManifests = new JSONModel(card),
        componentCardUrl = sap.ui.require.toUrl("sap/ui/integration/sample/CardsLayout/componentCard/manifest.json"),
        homeIconUrl = sap.ui.require.toUrl("sap/ui/integration/sample/CardsLayout/images/CompanyLogo.png");
      // cardManifests.loadData(sap.ui.require.toUrl("sap/uimodule/model/card.json"));

      this.getView().setModel(cardManifests, "manifests");
      this.getView().setModel(new JSONModel({
        componentCardUrl: componentCardUrl,
        homeIconUrl: homeIconUrl
      }));
    }
  });
});
