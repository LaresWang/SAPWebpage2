sap.ui.define([
  "sap/ui/test/Opa5",
  "ui/rangeslider/test/integration/arrangements/Startup",
  "ui/rangeslider/test/integration/BasicJourney"
], function(Opa5, Startup) {
  "use strict";

  Opa5.extendConfig({
    arrangements: new Startup(),
    pollingInterval: 1
  });

});
